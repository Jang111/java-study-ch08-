public class EX_02 {

	public static void main(String[] args) {
		try {
			try {
				
			}catch(Exception e1){
				
			}
		}catch(Exception e){
			try {
				
			}catch(Exception e2){
				
			}
		}
		try {
			
		}catch(Exception e){
			
		}
	}
}
